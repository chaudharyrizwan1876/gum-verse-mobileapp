import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import {
  FlatList,
  Text,
  TouchableOpacity,
  View,
} from "react-native";

import {
  Activity,
  Armchair,
  Dumbbell,
  Flame,
  HeartPulse,
  PersonStanding,
  Shield,
} from "lucide-react-native";

const exercises = [
  {
    name: "Chest",
    icon: HeartPulse,
    color: "#ff4d4d",
  },

  {
    name: "Biceps",
    icon: Dumbbell,
    color: "#7b61ff",
  },

  {
    name: "Triceps",
    icon: Shield,
    color: "#00c2ff",
  },

  {
    name: "Shoulders",
    icon: Activity,
    color: "#00d26a",
  },

  {
    name: "Back",
    icon: Armchair,
    color: "#ff9f0a",
  },

  {
    name: "Legs",
    icon: PersonStanding,
    color: "#ff2d55",
  },

  {
    name: "Abs",
    icon: Flame,
    color: "#ffd60a",
  },
];

export default function HomeScreen() {
  return (
    <View
      style={{
        flex: 1,
        backgroundColor: "#050505",
        paddingTop: 10,
        paddingHorizontal: 20,
      }}
    >
      <View
        style={{
          marginBottom: 35,
        }}
      >
        <LinearGradient
          colors={["#ff3131", "#ff6b00", "#ffd60a"]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 0 }}
          style={{
            alignSelf: "flex-start",
            paddingHorizontal: 18,
            paddingVertical: 6,
            borderRadius: 50,
            marginBottom: 18,
          }}
        >
          <Text
            style={{
              color: "white",
              fontSize: 13,
              fontWeight: "700",
              letterSpacing: 1,
            }}
          >
            PREMIUM FITNESS CLUB
          </Text>
        </LinearGradient>

        <Text
          style={{
            color: "white",
            fontSize: 58,
            fontWeight: "900",
            lineHeight: 60,
            letterSpacing: -2,
          }}
        >
          GymVerse
        </Text>

        <Text
          style={{
            color: "#888",
            fontSize: 18,
            marginTop: 10,
            lineHeight: 28,
            maxWidth: 280,
          }}
        >
          Unlock your beast mode and transform your physique ⚡
        </Text>
      </View>

      <FlatList
        data={exercises}
        keyExtractor={(item) => item.name}
        numColumns={2}
        showsVerticalScrollIndicator={false}
        columnWrapperStyle={{
          justifyContent: "space-between",
        }}
        renderItem={({ item }) => {
          const Icon = item.icon;

          return (
            <TouchableOpacity
              activeOpacity={0.85}
              onPress={() =>
                router.push({
                  pathname: "/exercise/[name]",
                  params: {
                    name: item.name,
                  },
                })
              }
              style={{
                width: "47%",
                height: 210,
                backgroundColor: "#111111",
                borderRadius: 32,
                padding: 18,
                marginBottom: 22,

                borderWidth: 1,
                borderColor: "#1f1f1f",

                shadowColor: item.color,
                shadowOffset: {
                  width: 0,
                  height: 10,
                },
                shadowOpacity: 0.25,
                shadowRadius: 20,

                elevation: 10,
              }}
            >
              <View
                style={{
                  width: 78,
                  height: 78,
                  borderRadius: 26,
                  backgroundColor: item.color,
                  justifyContent: "center",
                  alignItems: "center",

                  shadowColor: item.color,
                  shadowOffset: {
                    width: 0,
                    height: 8,
                  },
                  shadowOpacity: 0.5,
                  shadowRadius: 15,

                  elevation: 12,
                }}
              >
                <Icon size={42} color="white" strokeWidth={2.5} />
              </View>

              <View>
                <Text
                  style={{
                    color: "white",
                    fontSize: 26,
                    fontWeight: "800",
                    marginBottom: 6,
                  }}
                >
                  {item.name}
                </Text>

                <Text
                  style={{
                    color: "#777",
                    fontSize: 14,
                  }}
                >
                  Start training →
                </Text>
              </View>
            </TouchableOpacity>
          );
        }}
      />
    </View>
  );
}
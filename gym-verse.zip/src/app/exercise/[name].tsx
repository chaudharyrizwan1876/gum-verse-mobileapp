import { useLocalSearchParams } from "expo-router";
import {
  FlatList,
  Linking,
  Text,
  TouchableOpacity,
  View,
} from "react-native";

import { exercisesData } from "@/data/exercises";

export default function ExerciseScreen() {
  const { name } = useLocalSearchParams();

  const exerciseList =
    exercisesData[name as keyof typeof exercisesData];

  return (
    <View
      style={{
        flex: 1,
        backgroundColor: "#111",
        paddingTop: 80,
        paddingHorizontal: 20,
      }}
    >
      <Text
        style={{
          color: "white",
          fontSize: 35,
          fontWeight: "bold",
          marginBottom: 30,
        }}
      >
        {name} Exercises
      </Text>

      <FlatList
        data={exerciseList}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <TouchableOpacity
            onPress={() => Linking.openURL(item.video)}
            style={{
              backgroundColor: "#1e1e1e",
              padding: 20,
              borderRadius: 15,
              marginBottom: 20,
            }}
          >
            <Text
              style={{
                color: "white",
                fontSize: 22,
                fontWeight: "bold",
              }}
            >
              {item.name}
            </Text>

            <Text
              style={{
                color: "gray",
                marginTop: 10,
              }}
            >
              Watch Exercise Video
            </Text>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}
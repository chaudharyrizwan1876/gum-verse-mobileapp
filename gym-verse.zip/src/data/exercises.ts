export const exercisesData = {
  Chest: [
    {
      id: 1,
      name: "Push Ups",
      video: "https://www.youtube.com/watch?v=IODxDxX7oi4",
    },
    {
      id: 2,
      name: "Bench Press",
      video: "https://www.youtube.com/watch?v=rT7DgCr-3pg",
    },
  ],

  Biceps: [
    {
      id: 1,
      name: "Dumbbell Curl",
      video: "https://www.youtube.com/watch?v=ykJmrZ5v0Oo",
    },
    {
      id: 2,
      name: "Hammer Curl",
      video: "https://www.youtube.com/watch?v=zC3nLlEvin4",
    },
  ],

  Triceps: [
    {
      id: 1,
      name: "Tricep Dips",
      video: "https://www.youtube.com/watch?v=0326dy_-CzM",
    },
  ],

  Shoulders: [
    {
      id: 1,
      name: "Shoulder Press",
      video: "https://www.youtube.com/watch?v=qEwKCR5JCog",
    },
  ],

  Back: [
    {
      id: 1,
      name: "Pull Ups",
      video: "https://www.youtube.com/watch?v=eGo4IYlbE5g",
    },
  ],

  Legs: [
    {
      id: 1,
      name: "Squats",
      video: "https://www.youtube.com/watch?v=aclHkVaku9U",
    },
  ],

  Abs: [
    {
      id: 1,
      name: "Crunches",
      video: "https://www.youtube.com/watch?v=Xyd_fa5zoEU",
    },
  ],
};